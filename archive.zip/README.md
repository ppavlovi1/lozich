# lozich Open source password manager project

## ovo je testni commit

